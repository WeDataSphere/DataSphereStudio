package com.webank.wedatasphere.dss.guide.server.util;

public class GuideException extends Exception {

    public GuideException(final String message) {
        super(message);
    }
}
