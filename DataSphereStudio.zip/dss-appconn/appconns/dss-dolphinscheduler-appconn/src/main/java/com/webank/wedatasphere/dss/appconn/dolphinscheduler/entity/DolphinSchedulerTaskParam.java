package com.webank.wedatasphere.dss.appconn.dolphinscheduler.entity;


public class DolphinSchedulerTaskParam {

    private String rawScript;

    public String getRawScript() {
        return rawScript;
    }

    public void setRawScript(String rawScript) {
        this.rawScript = rawScript;
    }
}
