package org.apache.linkis.server

/**
 *
 * @date 2022-03-11
 * @author enjoyyin
 * @since 0.5.0
 */
object JSONUtils {

  val gson = BDPJettyServerHelper.gson

  val jackson = BDPJettyServerHelper.jacksonJson
}
